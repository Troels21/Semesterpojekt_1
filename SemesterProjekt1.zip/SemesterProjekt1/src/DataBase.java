import java.io.*;

public class DataBase {
    Main m = new Main();

        public void skrivData(String IR,String R){ //skriv til fil
            m.pw.println(IR + " :Ir    Red: " + R);
            m.pw.flush();

    }
}
