import java.io.*;

public class Main {
    static double[] ir = new double[15];
    static double[] red = new double[15];
    static double SPO2;

    BufferedWriter Writer;//Fil genering
    {
        try {
            Writer = new BufferedWriter(new FileWriter("D:\\Imam\\Desktop\\Uni-DTU\\Mine Opgaver\\1.Semester\\Semesterpojekt 1\\Database\\Data"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    PrintWriter pw = new PrintWriter(Writer);


    public static void main(String[] args) {
        Sensor ss = new Sensor();
        DataBase DB = new DataBase();

            for (int t = 0; t < 10; t++) {


                for (int i = 0; i < 10; i++) { //For løkke der printer til fil, samt indlogerer data i array
                    ss.maaling();
                    ir[i] = Double.parseDouble(ss.getMaalIR());
                    red[i] = Double.parseDouble(ss.getMaalR());
                    DB.skrivData(ss.getMaalIR(), ss.getMaalR());
                    System.out.println((i+1)+": "+ss.getMaalIR()+": IR     Red: "+ss.getMaalR());
                }

                for (int i = 0; i < 10; i++) { //Bubblesort
                    for (int j = 0; j < 10; j++) {
                        if (red[j] > red[j + 1]) {
                            double placeHolder = red[j];
                            red[j] = red[j + 1];
                            red[j + 1] = placeHolder;
                        }
                    }
                }
                for (int i = 0; i < 10; i++) {  //Bubblesort
                    for (int j = 0; j < 10; j++) {
                        if (ir[j] > ir[j + 1]) {
                            double placeHolder = ir[j];
                            ir[j] = ir[j + 1];
                            ir[j + 1] = placeHolder;
                        }
                    }
                }

                SPO2 = (110 - (25 * (((red[10] - red[0]) / red[6]) / ((ir[10] - ir[0]) / ir[6])))); // SPO2 formel fundet i https://www.ti.com/lit/an/slaa655/slaa655.pdf?ts=1609769454173&ref_url=https%253A%252F%252Fwww.google.com%252F 06-01-2021

                System.out.println("SPO2: " + SPO2 + " %");
            }
    }

}





