import jssc.SerialPort;
import jssc.SerialPortException;

public class Sensor {
    String maaling;
    String maalIR;
    String maalR;
    int malnr;
    public void maaling() { //setters her

        SerialPort sensor = new SerialPort("COM3"); //JSSC biblotek kommer fra  https://github.com/java-native/jssc/releases
        try {
            sensor.openPort();
            sensor.setParams(115200, 8, 1, 0);
            sensor.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
            sensor.setDTR(true);
            sensor.purgePort(SerialPort.PURGE_TXCLEAR | SerialPort.PURGE_RXCLEAR); //prøver at slette data, hvis der er data fra forrige læsning
            while (true) {
                if (sensor.getInputBufferBytesCount() > 0) {
                    String maaling = sensor.readString();
                    this.maaling=maaling;
                    this.malnr=maaling.indexOf(65); //Finder A i strengen der bliver overført
                    this.maalIR = maaling.substring((malnr + 4), (malnr + 10)); //Deler strengen op i Red or IR værdier
                    this.maalR = maaling.substring((malnr + 11), (malnr + 17));
                    //Thread.sleep(100);
                    break;
                } else {
                    Thread.sleep(1000);
                }

                }
        }
        catch (SerialPortException | InterruptedException e) {
            System.out.println("FEJL SERIALPORTEXCEPTION");
        }

        try {
            sensor.setDTR(false);
            sensor.closePort();

        } catch (SerialPortException ex) {
            System.out.println("");
        }
    }
    public String getMaalR(){ //Getters herunder
        return maalR;
    }
    public String getMaalIR(){
        return maalIR;
    }
    public String getMaaling(){
        return maaling;
    }
}
